class ReasonOpsError(Exception):
    """Base SDK exception for ReasonOps ITSM"""
    pass
